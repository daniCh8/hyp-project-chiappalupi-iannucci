# Hypermedia Applications Project

*Politecnico di Milano - Engineering of Computing Systems - 2019*

## Authors

* **[Daniele Chiappalupi](https://github.com/daniCh8)** - *868120*
* **[Elena Iannucci](https://github.com/eleiannu)** - *871782*